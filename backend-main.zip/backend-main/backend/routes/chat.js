import express from 'express';
import OpenAI from 'openai';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Initialize OpenAI client
let openai = null;
const getOpenAI = () => {
  if (!openai) {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
  }
  return openai;
};
// System prompt for Traffix AI assistant
const SYSTEM_PROMPT = `You are Traffix AI, an expert traffic analytics and optimization assistant. You help users analyze web traffic patterns, provide insights, suggest improvements, and answer questions about traffic optimization. You have deep knowledge of:

- Web analytics metrics (visitors, pageviews, bounce rate, session duration, conversion rates)
- Traffic sources (organic, direct, referral, social, email)
- SEO best practices
- User behavior analysis
- A/B testing and experimentation
- Conversion rate optimization
- Content strategy

Be helpful, concise, and actionable in your responses. When analyzing data, provide specific recommendations. Format your responses with markdown when appropriate (lists, bold text, etc.).`;

// Store conversation history in memory (in production, use a database)
const conversations = new Map();

// POST /api/chat - AI conversation endpoint
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;

    if (!message) {
      return res.status(400).json({
        error: 'Validation Error',
        message: 'Message is required'
      });
    }

    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      // Return a helpful demo response if no API key
      return res.json({
        response: `I'm the Traffix AI assistant! 🚗

Currently, the OpenAI API key is not configured on the server. In a production environment, I would analyze your traffic data and provide insights.

To enable AI features:
1. Get an API key from https://platform.openai.com/api-keys
2. Add it to your backend's .env file as OPENAI_API_KEY
3. Restart the server

Meanwhile, here are some general traffic optimization tips:
- **Improve page load speed** - Pages loading under 3 seconds have 53% lower bounce rates
- **Optimize for mobile** - Over 60% of traffic comes from mobile devices
- **Create quality content** - Engaging content keeps users on your site longer
- **Use clear CTAs** - Guide users toward your conversion goals
- **Monitor traffic sources** - Focus on high-converting channels`,
        conversationId: 'demo'
      });
    }

    // Build messages array for OpenAI
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...conversationHistory.slice(-10), // Keep last 10 messages for context
      { role: 'user', content: message }
    ];

    // Call OpenAI API
    const completion = await getOpenAI().chat.completions.create({
      model: 'gpt-4.1-mini',
      messages,
      max_tokens: 1000,
      temperature: 0.7
    });

    const aiResponse = completion.choices[0].message.content;

    res.json({
      response: aiResponse,
      conversationId: req.user.id
    });

  } catch (error) {
    console.error('Chat API error:', error);

    // Handle specific OpenAI errors
    if (error.status === 401) {
      return res.status(401).json({
        error: 'API Key Error',
        message: 'Invalid OpenAI API key'
      });
    }

    if (error.status === 429) {
      return res.status(429).json({
        error: 'Rate Limit',
        message: 'Too many requests. Please wait a moment and try again.'
      });
    }

    res.status(500).json({
      error: 'Chat Error',
      message: 'Failed to get response from AI'
    });
  }
});

export default router;

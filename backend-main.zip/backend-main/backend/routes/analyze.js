import express from 'express';
import OpenAI from 'openai';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// System prompt for traffic analysis
const ANALYSIS_PROMPT = `You are Traffix AI, an expert traffic analyst. Analyze the provided traffic data and generate actionable insights and recommendations. Your response should be in JSON format with the following structure:

{
  "score": number (0-100, overall health score),
  "summary": string (2-3 sentence summary),
  "insights": [
    {
      "metric": string (the metric name),
      "status": string ("good", "warning", "critical"),
      "description": string (what this means),
      "value": number or string (the actual value)
    }
  ],
  "recommendations": [
    {
      "priority": string ("high", "medium", "low"),
      "title": string (short title),
      "description": string (detailed explanation),
      "expected_impact": string (what improvement to expect)
    }
  ]
}

Be specific with numbers and provide actionable advice.`;

// Sample data for demo mode
const generateDemoAnalysis = (data) => {
  const score = Math.floor(Math.random() * 30) + 60; // 60-90 score
  return {
    score,
    summary: `Your traffic data shows ${data.visitors?.toLocaleString() || 'N/A'} visitors with a ${data.bounceRate || 45}% bounce rate. There's room for improvement in user engagement and conversion optimization.`,
    insights: [
      {
        metric: "Visitors",
        status: score > 70 ? "good" : "warning",
        description: "Total unique visitors in the analyzed period",
        value: data.visitors?.toLocaleString() || "N/A"
      },
      {
        metric: "Bounce Rate",
        status: data.bounceRate > 50 ? "critical" : data.bounceRate > 40 ? "warning" : "good",
        description: "Percentage of single-page sessions",
        value: `${data.bounceRate || 45}%`
      },
      {
        metric: "Session Duration",
        status: data.sessionDuration > 180 ? "good" : data.sessionDuration > 120 ? "warning" : "critical",
        description: "Average time users spend on your site",
        value: `${Math.floor((data.sessionDuration || 150) / 60)}m ${(data.sessionDuration || 150) % 60}s`
      },
      {
        metric: "Page Views",
        status: data.pageviews && data.visitors && data.pageviews / data.visitors > 3 ? "good" : "warning",
        description: "Total pages viewed",
        value: data.pageviews?.toLocaleString() || "N/A"
      }
    ],
    recommendations: [
      {
        priority: "high",
        title: "Reduce Bounce Rate",
        description: "Your bounce rate is above optimal. Improve page load times and create engaging above-the-fold content.",
        expected_impact: "Could reduce bounce rate by 15-25%"
      },
      {
        priority: "medium",
        title: "Increase Session Duration",
        description: "Add internal linking and related content suggestions to keep users engaged longer.",
        expected_impact: "Average session duration could increase by 30-60 seconds"
      },
      {
        priority: "low",
        title: "Diversify Traffic Sources",
        description: "Consider expanding into referral and social traffic channels.",
        expected_impact: "More resilient traffic profile"
      }
    ]
  };
};

// POST /api/analyze - Traffic analysis endpoint
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { visitors, pageviews, sessionDuration, bounceRate, sources } = req.body;

    // Validation
    if (!visitors && !pageviews && !sessionDuration && !bounceRate) {
      return res.status(400).json({
        error: 'Validation Error',
        message: 'At least one traffic metric is required (visitors, pageviews, sessionDuration, or bounceRate)'
      });
    }

    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      // Return demo analysis
      return res.json({
        analysis: generateDemoAnalysis({ visitors, pageviews, sessionDuration, bounceRate, sources }),
        demo: true,
        message: 'Running in demo mode. Add your OpenAI API key to .env for full AI-powered analysis.'
      });
    }

    // Build analysis prompt with user data
    const userDataSummary = `
Traffic Data to Analyze:
- Visitors: ${visitors || 'Not provided'}
- Pageviews: ${pageviews || 'Not provided'}
- Session Duration: ${sessionDuration ? `${Math.floor(sessionDuration / 60)}m ${sessionDuration % 60}s` : 'Not provided'}
- Bounce Rate: ${bounceRate ? `${bounceRate}%` : 'Not provided'}
- Traffic Sources: ${sources ? JSON.stringify(sources) : 'Not provided'}
    `.trim();

    const messages = [
      { role: 'system', content: ANALYSIS_PROMPT },
      { role: 'user', content: `Analyze this traffic data and provide insights:\n\n${userDataSummary}` }
    ];

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages,
      max_tokens: 1500,
      temperature: 0.5
    });

    let analysis;
    try {
      analysis = JSON.parse(completion.choices[0].message.content);
    } catch (parseError) {
      // If JSON parsing fails, return a structured fallback
      analysis = {
        score: 75,
        summary: completion.choices[0].message.content,
        insights: [],
        recommendations: []
      };
    }

    res.json({
      analysis,
      demo: false
    });

  } catch (error) {
    console.error('Analyze API error:', error);

    // Handle specific OpenAI errors
    if (error.status === 401) {
      return res.status(401).json({
        error: 'API Key Error',
        message: 'Invalid OpenAI API key'
      });
    }

    if (error.status === 429) {
      return res.status(429).json({
        error: 'Rate Limit',
        message: 'Too many requests. Please wait a moment and try again.'
      });
    }

    res.status(500).json({
      error: 'Analysis Error',
      message: 'Failed to analyze traffic data'
    });
  }
});

export default router;
